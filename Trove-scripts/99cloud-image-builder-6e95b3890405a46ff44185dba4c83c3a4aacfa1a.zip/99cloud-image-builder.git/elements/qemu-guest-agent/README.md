Require hw_qemu_guest_agent property in glance.

    glance image-create ...  --property hw_qemu_guest_agent=yes
